
# willse_backgammon

This project was created my me to practice and improve my python skils and to learn about nureal networks and machine learning. It is very much still a work in progress.


## Installation

You can install this project using pip:

```bash
  pip install willse_backgammon
```
    
## Run Locally

After Intsallation, you can run the main application with the following command from terminal:

```bash
  > willse_backgammon_run
```


## Features

- Two Player, Single Player, and Simulation Modes
- Multiple AI modles
- Currently v0.0.1


