#Welcome

This package is a project I have created to learn python as well as the basics of Artificial Intelligence. It is still a Work in Progress.
